<?php 

include('./inc/aik.config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
<meta content="black" name="apple-mobile-web-app-status-bar-style" /> 
<meta content="telephone=no" name="format-detection" /> 
<title><?php echo $aik['title'];?> 在线微博小视频播放</title>
<meta name="keywords" content="手机在线观看电视直播" />
<meta name="Description" content="智云影音在线电视直播" />
<style>
body{ font-family:"Microsoft Yahei",Tahoma,"SimSun"; background:#fafafa; -webkit-text-size-adjust:none;}
body,div,dl,dt,dd,ul,ol,li,h1,h2,pre,blockquote{margin:0;padding:0;}
a{ color:#0b337b; text-decoration:none;}
.wrap{}
/*提示*/
.tz{ padding:5px; font-size:18px;}
.tz h2{ margin-bottom:10px; font-size:24px; font-weight:bold;}
.tz div{ margin-bottom:10px; line-height:24px;}
.tz div span{ color:#0b337b;}

.center { text-align: center;}

.butn_bg {
padding: 5px;
display: block;
color: #fff;
background: #4998e7;
height: 60px;
text-align: center;
border-radius: 4px;
}
.butn_bg , .butn_bg a{
	display: block;
	line-height: 30px !important;
	color: #fff;
}
.marquee-box {
	width: 96%;
	margin: 0 auto;
}
</style>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?1c7e5db7286d0df78e67d1b5a2c09a6a";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>

</head>

<body>
	<div class="center"><a href="https://github.com/zhizg/b" target="_blank" ><img src="images/logo.png" width="310" height="100" alt="智卓星网logo"></a>
    </div>
<div class="tz">
	<div class="marquee-box">
		<marquee direction="left" behavior="scroll" scrollamount="8" bgcolor=" " height="" scrolldelay="" style="color:red; text-align: center;">
	    提示:本服务使用完全免费！点击刷新，重新加载，显示更多最新视频哦！或者刷新页面，随机展示视频！更多精彩内容，请访问智云解析官网：https://github.com/zhizg/b，反馈交流请加入官方QQ交流群，或者关注官方博客！
		</marquee>
	</div><hr><p><center><iframe width="280" scrolling="no" height="25" frameborder="0" allowtransparency="true" src="http://i.tianqi.com/index.php?c=code&id=34&icon=1&num=3"></iframe></center>
	<p class="center" style="font-size:14px;"><span style="color:#fd891a;">智云提示您：</span>刷新本页面重新加载视频</p>
	<p class="center"></p>
</div>
</div>
<!--直播开始-->

<script>
var w = '100%'; //宽度
var h = '2000'; //高度
var s = 'yes'; //是否显示滚动条，yes显示，no不显示
document.write('<iframe width='+w+' height='+h+' src="https://m.weibo.cn/p/231159" frameborder=0 border=0 marginwidth=0 marginheight=0 scrolling='+s+'></iframe>');
</script>

<!--直播结束-->


<hr>
<br>
  <br>
  <div align="center" class="STYLE2"> </div>
    <div align="center" class="STYLE1"><a href="https://github.com/zhizg/b" target="_blank">官方平台</a> <a href="javascript:history.back()" target="_blank">返回上一页</a></div>
    <table border=2 width=100%>
   <tbody>
     <tr>
	<div class="ts">
<td bgcolor="#ACA899"><center><a href="javascript:location.reload()" onclick="_dct_("dh_m_phb");" class="aRank"><span><font size=4>☞点我刷新-从新加载-更多精彩☜</span></a><br/></center></td>
	<div class="ts">
    </tr>
  </tbody></table>
<table border=2 width=100%>
	<div class="ts"><script>bopay();</script>

</div>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?1c7e5db7286d0df78e67d1b5a2c09a6a";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
</div>
<!--360自动提交连接-->
<script>
(function(){
var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?d4d9f371abe1a3935500b5aaf98e676d":"https://jspassport.ssl.qhimg.com/11.0.1.js?d4d9f371abe1a3935500b5aaf98e676d";
document.write('<script src="' + src + '" id="sozz"><\/script>');
})();
</script>
<script language="javascript" type="text/javascript" src="http://js.users.51.la/18759442.js"></script>
<noscript><a href="http://www.51.la/?18759442" target="_blank"><img alt="&#x6211;&#x8981;&#x5566;&#x514D;&#x8D39;&#x7EDF;&#x8BA1;" src="http://img.users.51.la/18759442.asp" style="border:none" /></a></noscript>
</div>
<!-- JiaThis Button BEGIN -->
<div class="jiathis_style_m"></div>
<script type="text/javascript" src="http://v3.jiathis.com/code/jiathis_m.js" charset="utf-8"></script>
<!-- JiaThis Button END -->
</body>
</html>
