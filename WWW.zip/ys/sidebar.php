<?php 
?><?='<div class="sidebar">
<div class="widget widget-textasst">'; echo $aik['cebian1_ad'];?><?='</div>
<div class="widget widget-textasst">'; echo $aik['cebian2_ad'];?><?='</div>
<div class="widget widget_text">'; echo $aik['cebian3_ad'];?><?='</div> </div>
<div class="widget widget-textasst">'; echo $aik['cebian4_ad'];?><?="</div>	
  
		
		<script>
var ifh=$('.sidebar');
if(ifh.height()<10){
$('.content').css(\"width\",\"100%\");
}else{
}</script>";?>
