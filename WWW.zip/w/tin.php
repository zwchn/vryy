<?php
include ('../inc/aik.config.php');
?>
<!DOCTYPE html>

<html lang="zh-cn">

<head>

  <meta charset="utf-8"/>

  <meta name="viewport" content="width=device-width, initial-scale=1"/>


<title>要听DJ网音频在线解析播放平台–<?php echo $aik['sitename'];?></title>
<meta name="keywords" content="<?php echo $aik['title'];?>,在线解析,电视直播网站,零八影院快播,高清云影视,云点播,免费看视频,湖南卫视直播,80电影网,最新电影天堂免费在线观看">
<meta name="description" content="<?php echo $aik['sitename'];?>,DJ音频解析，在线音频解析" />
  <link href="https://cdn.bootcss.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet"/>

  <script src="https://cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>

  <script src="https://cdn.bootcss.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <script type="text/javascript">eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('b a(){0 6=1.2("9").4;0 5=1.2("3");0 3=1.2("3").c;0 8=5.e[3].4;0 7=1.2("f");7.d=8+6}',16,16,'var|document|getElementById|jk|value|jkurl|diz|cljurl|jkv|url|dihejk|function|selectedIndex|src|options|player'.split('|'),0,{}))</script>

</head>

<body background="bj.png">

  <div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 center-block" style="float: none;">

  <h3 class="text-muted" align="center"><?php echo $aik['sitename'];?>DJ音频解析站</h3>

  <center>

   <span style="color:red"><marquee behavior="scroll">
   请输入数字范围（10到203999），点击播放即可！有问题请联系官方平台
   </marquee></span>

  </center>

<hr>
 
     </div>

 </div> 

 <table class="table table-bordered">

 <tbody>

	<div class="col-md-14 column">

    <div class="panel panel-default">

     <div id="kj" class="panel-body">

      <iframe src="ting.html" id="player" width="100%" height="400px" allowtransparency="true" frameborder="0" scrolling="no"></iframe>

     </div>

    </div>

   </div>

   <tr>

   <div class="col-md-14 column">

    <form method="get" id="1233911832">

     <div class="input-group" style="width: 100%;">

      <span class="input-group-addon input-lg" style="width: 80px; ">数字范围</span>

      <select class="form-control input-lg" id="jk">

<option value="ting.php?id=">输入（10到203999）</option>
 </select>

     </div>

     <br>

     <div class="input-group" style="width: 100%;">

             <span class="input-group-addon input-lg" style="width: 80px;">输入数字</span>

             <input class="form-control input-lg" type="search" placeholder="输入数字范围10到203999" id="url">

     </div>

        <br>

         <div>

             <button id="bf" type="button" class="btn btn-success btn-lg btn-block" onClick="dihejk()">播放</button>

     </div>
   </div>
  
  
   	<table class="table table-bordered">
	<thead>
		<tr>
			<th>使用介绍</th>
		</tr>
	</thead>
	<tbody>
		<tr>
            <td><b>
<ol><h5><b>
<li>DJ要听网解析播放说明：输入相对应的数字范围内即可在线解析播放或下载，<p>两至六位数字范围（10到203999）！！<p>例如:123</li><br><li>提示:解析过程需要缓冲一下，会自动提示播放或者下载缓存</li><br>
</h5>
</ol>
			</b>
 </td>
		</tr>
      </tbody>     
</div>
       </div>
       <!--百度收录自动推送-->
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';        
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
<script language="javascript" type="text/javascript" src="http://js.users.51.la/18759442.js"></script>
</body>
</html>
