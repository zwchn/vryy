<?php
include ('./inc/aik.config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta http-equiv="cache-control" content="no-siteapp">
<title><?php echo $aik['title'];?>-免VIP抢先观看最新好看的电影和电视剧</title>
<link rel='stylesheet' id='main-css'  href='css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-css'  href='css/index.css' type='text/css' media='all' />
<script type='text/javascript' src='http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js?ver=0.5'></script>
<meta name="keywords" content="<?php echo $aik['title'];?>,电视直播网站,零八影院快播,高清云影视,云点播,免费看视频,湖南卫视直播,80电影网,最新电影天堂免费在线观看">
<meta name="description" content="<?php echo $aik['title'];?>,热剧快播,最好看的剧情片尽在<?php echo $aik['title'];?>,高清云影视免费为大家提供最新最全的免费电影，电视剧，综艺，动漫无广告在线云点播，以及电视直播">
<!--[if lt IE 9]><script src="js/html5.js"></script><![endif]-->
</head>
<body>
<body class="page-template page-template-pages page-template-posts-film page-template-pagesposts-film-php page page-id-9">
<?php  include 'header.php';?>
<section class="container">
<!--直播开始-->

<meta http-equiv="refresh" content="0.2;url=zba.php">
<script language="javascript">alert('正在为您进入精彩主播直播频道')</script>
        <iframe src="http://h5.live.xunlei.com/h5/" width="0"></iframe>
<strong></strong><h2></p></a>
</div><h2>正在为您进入精彩主播直播频道.....</h2>
 <h3>提示:本直播平台功能仅供手机版在线观看哦！下拉可展开更多主播频道!</h3>
  <ul>
  
<b><li>说明：功能仅支持手机观看进入主播直播频道，可下拉刷新，展开更多主播直播频道哦，功能仅支持手机在线播放哦。</li><li>本功能直播平台仅供手机浏览器在线观看或者下载官方APP播放哦！</li></b>
  </ul>
  <style>
    html,body{
      height: 100vh;
      width: 100vw;
      margin: 0;
      padding: 0;
      background: #ffffff;
      text-align: center;
      margin-top:30px;
      overflow: hidden;
    }
    *{
      color:rgb(100,100,100);
    }
    a{
      color:#42b983;
    }
    ul,li{
      margin: 0;
    }
    ul{
      margin-left: -40px;
      line-height: 30px;
    }
    li{
      list-style: none;
    }
  </style>
<!--直播结束-->
</section>

<?php  include 'footer.php';?>
</body>
</html>
