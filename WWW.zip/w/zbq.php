<?php
include ('../inc/aik.config.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
<meta content="black" name="apple-mobile-web-app-status-bar-style" /> 
<meta content="telephone=no" name="format-detection" /> 
<title>手机在线电视直播 <?php echo $aik['title'];?></title>
<meta name="keywords" content="<?php echo $aik['title'];?>,电视直播网站,零八影院快播,高清云影视,云点播,免费看视频,湖南卫视直播,80电影网,最新电影天堂免费在线观看">
<meta name="description" content="<?php echo $aik['title'];?>,热剧快播,最好看的剧情片尽在<?php echo $aik['title'];?>,高清云影视免费为大家提供最新最全的免费电影，电视剧，综艺，动漫无广告在线云点播，以及电视直播">
<style>
body{ font-family:"Microsoft Yahei",Tahoma,"SimSun"; background:#fafafa; -webkit-text-size-adjust:none;}
body,div,dl,dt,dd,ul,ol,li,h1,h2,pre,blockquote{margin:0;padding:0;}
a{ color:#0b337b; text-decoration:none;}
.wrap{}
/*提示*/
.tz{ padding:5px; font-size:18px;}
.tz h2{ margin-bottom:10px; font-size:24px; font-weight:bold;}
.tz div{ margin-bottom:10px; line-height:24px;}
.tz div span{ color:#0b337b;}

.center { text-align: center;}

.butn_bg {
padding: 5px;
display: block;
color: #fff;
background: #4998e7;
height: 60px;
text-align: center;
border-radius: 4px;
}
.butn_bg , .butn_bg a{
	display: block;
	line-height: 30px !important;
	color: #fff;
}
.marquee-box {
	width: 96%;
	margin: 0 auto;
}
</style>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?1c7e5db7286d0df78e67d1b5a2c09a6a";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>

</head>

<body>
	<div class="center"><a href="../index.php" target="_blank" ><img src="../images/logo.png" width="310" height="100" alt="智卓星网logo"></a>
    </div>
<div class="tz">
	<div class="marquee-box">
		<marquee direction="left" behavior="scroll" scrollamount="8" bgcolor=" " height="" scrolldelay="" style="color:red; text-align: center;">
	    公告:本服务使用完全免费！<?php echo $aik['title'];?>提示：点击：进入更多视频播放，展开列表选择更多频道进行观看！更多精彩内容，请访问智云解析官网：https://github.com/zhizg/b，反馈交流请加入官方QQ交流群，或者关注官方博客！
		</marquee>
	</div><hr><p><center><iframe width="280" scrolling="no" height="25" frameborder="0" allowtransparency="true" src="http://i.tianqi.com/index.php?c=code&id=34&icon=1&num=3"></iframe></center>
	<p class="center" style="font-size:14px;"><span style="color:#fd891a;">提示您：</span>点击更多，更换其他影音直播频道</p>
	<p class="center">功能仅支持手机在线播放观看哦</p>
</div>
</div>
<iframe src="http://m.153cn.com/ke/zbq.html" marginheight="10" marginwidth="20" frameborder="0" scrolling="no" width=100% height=360 id="iframepage" name="iframepage"></iframe>
<hr>
<br>
</div><div><marquee scrollamount=2 FONT style="COLOR: #FF00FF; FILTER: glow(color=FFFF66); FONT-FAMILY: 华文彩云; FONT-SIZE: 15pt; WIDTH: 100%"><B>欢迎您使用（<?php echo $aik['title'];?>影视）直播系统 ！功能仅支持手机在线播放哦！播放有问题请联系官方QQ交流群或者站长哦</B></FONT></marquee></div>
  <br>
  <div align="center" class="STYLE2"> </div>
    <div align="center" class="STYLE1"><a href="../index.php" target="_blank">返回首页</a> <a href="javascript:history.back()" target="_blank">返回上页</a></div>
    <table border=2 width=100%>
   <tbody>
     <tr>
	<div class="ts">
<td bgcolor="#ACA899"><center><a href="javascript:location.reload()" onclick="_dct_("dh_m_phb");" class="aRank"><span><font size=4>☞点我刷新-从新加载-清除缓存☜</span></a><br/></center></td>
	<div class="ts">
    </tr>
  </tbody></table>
<table border=2 width=100%>
	<div class="ts"><script>bopay();</script>

</div>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?1c7e5db7286d0df78e67d1b5a2c09a6a";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
</div>
<!--360自动提交连接-->
<script>
(function(){
var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?d4d9f371abe1a3935500b5aaf98e676d":"https://jspassport.ssl.qhimg.com/11.0.1.js?d4d9f371abe1a3935500b5aaf98e676d";
document.write('<script src="' + src + '" id="sozz"><\/script>');
})();
</script>
<script language="javascript" type="text/javascript" src="http://js.users.51.la/18759442.js"></script>
<noscript><a href="http://www.51.la/?18759442" target="_blank"><img alt="&#x6211;&#x8981;&#x5566;&#x514D;&#x8D39;&#x7EDF;&#x8BA1;" src="http://img.users.51.la/18759442.asp" style="border:none" /></a></noscript>
</div>
<!-- JiaThis Button BEGIN -->
<div class="jiathis_style_m"></div>
<script type="text/javascript" src="http://v3.jiathis.com/code/jiathis_m.js" charset="utf-8"></script>
<!-- JiaThis Button END -->
</body>
</html>
