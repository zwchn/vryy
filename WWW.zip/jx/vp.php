<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" /> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>智云影音VIP视频免费解析在线观看</title>
<script src="m.js" type="text/javascript"></script>
<link href="sty.css" rel="stylesheet">
</head>
<body>
<div id="a1" class="player"><iframe id="player" width="100%" height="100%" allowfullscreen="true"  scrolling="no" frameborder="0"  border="0" marginwidth="0" marginheight="0"  src="http://jx.zzit.cc/tv.php?url=<?php echo $_GET['url'];?>"></iframe></div>
<div id=lines> 
<ul> 
  <a href="javascript:void(0);" onClick="playlist(this)"  id="http://660e.com/?url=<?php echo $_GET['url'];?>"><li class="line" data-url="">线路一</li></a>
  <a href="javascript:void(0);" onClick="playlist(this)"  id="http://yanllcn.duapp.com/daidai/index.php?url=<?php echo $_GET['url'];?>"><li class="line" data-url="">线路二</li></a>
  <a href="javascript:void(0);" onClick="playlist(this)"  id="https://api.pangujiexi.com/player.php?url=<?php echo $_GET['url'];?>"><li class="line" data-url="">线路三</li></a>
  <a href="javascript:void(0);" onClick="playlist(this)"  id="http://www.dgua.xyz/webcloud/?url=<?php echo $_GET['url'];?>"><li class="line" data-url="">线路四</li></a>
  <a href="javascript:void(0);" onClick="playlist(this)"  id="http://api.ataoju.com/play/?url=<?php echo $_GET['url'];?>"><li class="line" data-url="">线路五</li></a>
</ul>
</div>
<script type="text/javascript"> function (url) { $('#player').attr('src', decodeURIComponent(decodeURIComponent(url))).show(); } </script>
  <script>
$(function(){
		//$(".line:first").css({"margin-color":"#ff0","color":"#ff0"})
		$(".line").click(function(){
		$(".line").css({"margin-color":"#fff","color":"#fff"});
		$(this).css({"margin-color":"#ff0","color":"#ff0"})
		})
	})
</script>
  <script>
function playlist(a){
    var mm=document.getElementById("player");
    mm.src=a.id;
    mm.play();
    }
</script>
<!--百度收录自动推送-->
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';        
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>

<script language="javascript" type="text/javascript" src="http://js.users.51.la/18759442.js"></script>
</div></body>
</html>
